package org.zerock.ex3.member.security.auth;

import lombok.RequiredArgsConstructor;

import java.security.Principal;


@RequiredArgsConstructor
public class CustomUserPrincipal implements Principal { // Principal : 인증된 사용자(Principal)를 나타내는 인터페이스
  // Principal 인터페이스를 구현함으로써, 이 클래스는 "인증된 사용자 정보" 객체로 동작할 수 있다.

  private final String mid;

  @Override
  public String getName() {
    return mid;
  }
}
