package org.zerock.ex3.member.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.zerock.ex3.member.entity.MemberEntity;

public interface MemberRepository extends JpaRepository<MemberEntity, String> {
    //  Spring Data JPA에서 데이터베이스와 자동으로 연동하기 위한 리포지토리 인터페이스

}
